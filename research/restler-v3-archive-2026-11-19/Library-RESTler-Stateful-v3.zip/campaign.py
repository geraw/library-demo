"""Run RESTler and EvoMaster on isolated Library SUT arms."""

import argparse
from collections import Counter
from contextlib import contextmanager
import csv
import json
import os
from pathlib import Path
import secrets
from restler_support import project_spec, verify_grammar, installation_manifest, relation_counts, native_analysis_status
import socket
import subprocess
import sys
sys.dont_write_bytecode = True
import time
import uuid

SETS = {
    "literature-v003": (23600, "B", 6, "mutants-v003/mutants.py"),
    "netbox-gitea": (23601, "F", 6, "sut/library_sut_netbox_gitea.py"),
    "featurefuzz": (23602, "C", 3, "feature-mutants-v001/server.py"),
}
TOOLS = ("restler", "evomaster")
HERE = Path(__file__).resolve().parent


@contextmanager
def service(bench, args, folder, arm, contract, bench_dir):
    with socket.socket() as probe:
        if probe.connect_ex(("127.0.0.1", args.port)) == 0:
            raise RuntimeError(f"Port {args.port} is occupied")
    token = secrets.token_hex(32)
    env = dict(os.environ, BENCH_SERVICE_TOKEN=token, LIBRARY_CAMPAIGN_REPO=str(args.repo),
               LIBRARY_CAMPAIGN_SET=args.set_name, LIBRARY_CAMPAIGN_ARM=arm)
    port = str(args.port)
    base = f"http://127.0.0.1:{port}"
    command = [sys.executable, str(bench_dir / "server_v001.py"), "--sut", str(HERE / "sut_cell.py"),
               "--trace", str(folder / "http.jsonl"), "--contract", str(contract), "--port", port]
    with (folder / "server.log").open("w", encoding="utf8") as log:
        proc = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=env,
                                start_new_session=os.name != "nt")
        try:
            for _ in range(100):
                if proc.poll() is not None:
                    raise RuntimeError("Server exited during startup; see server.log")
                try:
                    with socket.create_connection(("127.0.0.1", args.port), timeout=0.25):
                        pass
                except OSError:
                    time.sleep(0.1)
                    continue
                health = bench.call(base + "/__bench__/health")
                if health.get("token") != token:
                    raise RuntimeError("Listener identity mismatch")
                boundary = bench.call(base + "/__bench__/case", token, {"case": arm})
                if not boundary.get("empty_verified"):
                    raise RuntimeError("Initial state was not verified empty")
                yield base
                break
            else:
                raise RuntimeError("Server did not become ready; see server.log")
        finally:
            bench.terminate(proc)


def read_config(bench, args, bench_dir):
    candidate = args.config or bench_dir / "tools.local.json"
    if not candidate.is_file() and args.config is not None:
        raise FileNotFoundError(candidate)
    cfg = bench.tool_config(candidate if candidate.is_file() else bench_dir / "tools.example.json")
    for key in ("evomaster_jar", "restler", "java", "dotnet", "restler_python_bin"):
        override = getattr(args, key)
        if override:
            cfg[key] = override
        value = cfg.get(key)
        if value and (key in ("evomaster_jar", "restler", "restler_python_bin") or
                      "/" in value or "\\" in value):
            cfg[key] = str(Path(value).expanduser().resolve())
    for binary in ("java", "dotnet"):
        cfg[binary] = cfg.get(binary) or binary
    if "restler" in args.tools and not Path(cfg.get("restler") or ".").is_file():
        raise RuntimeError("Set -RestlerPath to Restler.exe or Restler.dll, or configure tools.local.json")
    if "evomaster" in args.tools and not Path(cfg.get("evomaster_jar") or ".").is_file():
        raise RuntimeError("Set -EvoMasterJar to evomaster.jar, or configure tools.local.json")
    return cfg


def native_command(bench, args, cfg, native, tool, folder, contract, env):
    base = f"http://127.0.0.1:{args.port}"
    if tool == "evomaster":
        return [cfg["java"], "-jar", native["jar"], "--blackBox", "true",
                native["schema_flag"], contract, native["base_flag"], base,
                "--maxTime", f"{args.seconds}s", "--seed", args.seed,
                "--outputFolder", folder / "generated-tests"]
    driver = native["driver"]
    current = installation_manifest(cfg['restler'])
    if current != args.installation_manifest:
        raise RuntimeError('RESTler installation changed since preflight; stop and inspect installation-integrity.json')
    compiled = folder / "Compile"
    config = folder / "compiler-config.json"
    bench.write(config, {"SwaggerSpecFilePath": [str(contract)],
        "GrammarOutputDirectoryPath": str(compiled), "ResolveBodyDependencies": True,
        "ResolveQueryDependencies": True, "UseBodyExamples": False, "UseQueryExamples": False})
    result = bench.launch(driver + ["--disable_log_upload", "compile", config], folder, "compile", 300, env)
    bench.require(result, folder, "compile")
    compiled = folder / "Compile"
    grammar, dictionary = compiled / "grammar.py", compiled / "dict.json"
    if not grammar.is_file() or not dictionary.is_file():
        raise RuntimeError("RESTler compiler did not produce grammar.py and dict.json")
    bench.write(folder / "dependency-check.json", verify_grammar(grammar))
    settings = {"target_ip": "127.0.0.1", "target_port": args.port,
                "host": f"127.0.0.1:{args.port}", "no_ssl": True,
                "time_budget": args.seconds / 3600, "fuzzing_mode": "directed-smoke-test" if args.smoke else args.search_strategy,
                "random_seed": args.seed, "garbage_collector_cleanup_time": 5,
                "max_request_execution_time": 10, "reconnect_on_every_request": True}
    if (compiled / "grammar.json").is_file():
        settings["grammar_schema"] = str(compiled / "grammar.json")
    bench.write(folder / "settings.json", settings)
    extra = []
    if not args.smoke:
        extra += ['--search_strategy', args.search_strategy]
        if args.checker_profile == 'stateful':
            extra += ['--disable_checkers', 'invalidvalue,payloadbody,invaliddynamicobject']
    return driver + ["--disable_log_upload", "test" if args.smoke else "fuzz", "--grammar_file", grammar, "--dictionary_file", dictionary,
                     "--settings", folder / "settings.json", "--no_ssl"] + extra


def evidence(folder):
    statuses = Counter()
    server_errors = []
    trace = folder / "http.jsonl"
    if trace.is_file():
        with trace.open(encoding="utf8") as stream:
            for line in stream:
                row = json.loads(line)
                if row["role"] == "tool":
                    statuses[row["status"]] += 1
                    if row["status"] >= 500:
                        server_errors.append({key: row[key] for key in
                                              ("order", "method", "url", "status")})
    artifacts = []
    for file in folder.rglob("*"):
        if file.is_file() and (file.name in ("bug_buckets.txt", "testing_summary.json", "native.log")
                               or "bug_buckets" in file.relative_to(folder).parts
                               or "generated-tests" in file.relative_to(folder).parts):
            artifacts.append(file.relative_to(folder).as_posix())
    return {"http_requests": sum(statuses.values()), "http_status_counts": dict(sorted(statuses.items())),
            "server_error_exchanges": server_errors, "native_evidence_files": sorted(artifacts),
            "native_report_review": "PENDING" if artifacts else "NO_ARTIFACT",
            "mutation_attribution": "REVIEW_REQUIRED"}


def write_summary(bench, root, rows):
    bench.write(root / "summary.json", rows)
    columns = ("tool", "arm", "execution", "http_requests", "server_error_count",
               "loans_created", "holds_created", "native_analysis_status", "baseline_execution", "baseline_http_requests", "baseline_server_error_count",
               "native_report_review", "mutation_attribution", "directory", "error")
    with (root / "summary.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def run(args):
    bench_dir = args.repo / "library" / "benchmark-v001"
    library = args.repo / "library"
    required = (bench_dir / "campaign_v001.py", library / SETS[args.set_name][3],
                library / "mutants-v003" / "original.py", library / "sut" / "BUG_README.MD")
    for path in required:
        if not path.is_file():
            raise FileNotFoundError(f"{path}; use the integrated Library SUT revision")
    sys.path.insert(0, str(bench_dir))
    import campaign_v001 as bench

    cfg = read_config(bench, args, bench_dir)
    root = args.output_base / (args.set_name + "-" + time.strftime("%Y%m%d-%H%M%S") +
                               "-" + uuid.uuid4().hex[:6])
    root.mkdir(parents=True)
    print(f"RUN_DIRECTORY {root}", flush=True)
    contract = root / "openapi.json"
    spec = json.loads((bench_dir / "openapi.json").read_text(encoding="utf8"))
    bench.write(root / "openapi-original.json", spec)
    spec = project_spec(spec, args.port)
    bench.write(contract, spec)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    if cfg.get("restler_python_bin"):
        env["PATH"] = cfg["restler_python_bin"] + os.pathsep + env.get("PATH", "")
    if os.name == "nt" and cfg.get("dotnet") and Path(cfg["dotnet"]).is_file():
        env["PATH"] = str(Path(cfg["dotnet"]).parent) + os.pathsep + env.get("PATH", "")
        env.setdefault("DOTNET_ROOT", str(Path(cfg["dotnet"]).parent))
    # Preflight inherits exactly the same environment as compilation and execution.
    os.environ.update(env)
    env['RESTLER_TELEMETRY_OPTOUT'] = '1'
    os.environ['RESTLER_TELEMETRY_OPTOUT'] = '1'
    if 'restler' in args.tools:
        args.installation_manifest = installation_manifest(cfg['restler'])
        bench.write(root / 'installation-integrity.json', args.installation_manifest)
    source = library / SETS[args.set_name][3]
    bench.write(root / "campaign-inputs.json", {
        "set": args.set_name, "phase": "smoke" if args.smoke else "fuzz",
        "minimum_relationships": 1 if args.smoke else args.minimum_relationships,
        "search_strategy": args.search_strategy, "checker_profile": args.checker_profile,
        "disabled_checkers": ["invalidvalue", "payloadbody", "invaliddynamicobject"] if args.checker_profile == "stateful" else [],
        "input_domain": "positive-integer ID branch; explicit public producer-consumer annotations", "tools": args.tools, "arms": args.arms, "port": args.port,
        "budget_seconds_per_cell": args.seconds, "seed": args.seed,
        "source": str(source.relative_to(args.repo)), "source_sha256": bench.sha(source),
        "original_sha256": bench.sha(library / "mutants-v003" / "original.py"),
        "contract_sha256": bench.sha(contract), "budget_type": "equal nominal time; request counts observed",
    })
    rows = []
    try:
        native = {}
        preflight_errors = {}
        for tool in args.tools:
            try:
                (root / ("preflight-" + tool)).mkdir()
                native[tool] = bench.preflight(root / ("preflight-" + tool), cfg, [tool])[tool]
            except (OSError, RuntimeError) as exc:
                if "LOW_DISK_SPACE" in str(exc):
                    raise
                preflight_errors[tool] = str(exc)
        baseline_by_tool = {}
        for tool in args.tools:
            for arm in args.arms:
                folder = root / tool / arm
                folder.mkdir(parents=True)
                print(f"START {tool} {arm}", flush=True)
                row = {"tool": tool, "arm": arm, "directory": folder.relative_to(root).as_posix()}
                try:
                    if tool in preflight_errors:
                        raise RuntimeError("Tool preflight failed: " + preflight_errors[tool])
                    command = native_command(bench, args, cfg, native[tool], tool, folder, contract, env)
                    with service(bench, args, folder, arm, contract, bench_dir):
                        result = bench.launch(command, folder, "native", args.seconds + 180, env)
                    row["execution"] = ("COMPLETED" if result["expected_exit"] else
                                        "TIMEOUT" if result["watchdog_timeout"] else "NONZERO_EXIT")
                    row["exit_code"] = result["exit_code"]
                except (OSError, RuntimeError, subprocess.SubprocessError) as exc:
                    if "LOW_DISK_SPACE" in str(exc):
                        raise
                    row.update(execution="FAILED", error=str(exc))
                if tool == 'restler':
                    try:
                        after = installation_manifest(cfg['restler'])
                        bench.write(folder / 'installation-after.json', after)
                        if after != args.installation_manifest:
                            raise RuntimeError('RESTler installation changed during execution')
                    except (OSError, RuntimeError) as exc:
                        row.update(execution='INSTALLATION_CHANGED', error=str(exc))
                row.update(evidence(folder))
                if tool == 'restler':
                    row['native_analysis_status'] = native_analysis_status(folder)
                    if row['execution'] == 'COMPLETED' and row['native_analysis_status'] != 'COMPLETED':
                        row.update(execution='PARTIAL_ANALYSIS', error='Native engine ended, but native results analysis failed or did not run')
                row.update(relation_counts(folder))
                if arm == 'baseline' and row['execution'] == 'COMPLETED':
                    minimum = 1 if args.smoke else args.minimum_relationships
                    if row['loans_created'] < minimum or row['holds_created'] < minimum:
                        row.update(execution='INSUFFICIENT_BUSINESS_COVERAGE',
                            error=f'Baseline needs at least {minimum} successful loans AND holds; refusing to score mutants')
                if row["execution"] == "COMPLETED" and not row["http_requests"]:
                    row["execution"] = "NO_HTTP_REQUESTS"
                row["server_error_count"] = len(row["server_error_exchanges"])
                if arm == "baseline":
                    baseline_by_tool[tool] = row
                    row["mutation_attribution"] = "BASELINE"
                elif tool in baseline_by_tool:
                    baseline = baseline_by_tool[tool]
                    for field in ("execution", "http_requests", "server_error_count"):
                        row["baseline_" + field] = baseline[field]
                bench.write(folder / "cell.json", row)
                rows.append(row)
                write_summary(bench, root, rows)
                print(f'END {tool} {arm} {row["execution"]} requests={row["http_requests"]} '
                      f'loans={row["loans_created"]} holds={row["holds_created"]}', flush=True)
                if row['execution'] == 'INSTALLATION_CHANGED' or (arm == 'baseline' and row['execution'] != 'COMPLETED'):
                    raise RuntimeError('Baseline or installation gate failed; evidence saved; no mutants started')
    except BaseException as exc:
        bench.write(root / "failure.json", {"error": str(exc), "finished_cells": len(rows)})
        raise
    print(f"SUMMARY {root / 'summary.csv'}", flush=True)
    return 0 if all(row["execution"] == "COMPLETED" for row in rows) else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--set", dest="set_name", required=True, choices=SETS)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--output-base", required=True, type=Path)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--seconds", type=int, default=60)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--port", type=int)
    parser.add_argument("--tools", default=",".join(TOOLS))
    parser.add_argument("--arms")
    parser.add_argument("--smoke", action="store_true")
    parser.add_argument("--minimum-relationships", type=int, default=10)
    parser.add_argument('--search-strategy', choices=['bfs-cheap', 'bfs-fast', 'random-walk'], default='random-walk')
    parser.add_argument('--checker-profile', choices=['full', 'stateful'], default='stateful')
    for key in ("evomaster-jar", "restler", "java", "dotnet", "restler-python-bin"):
        parser.add_argument("--" + key)
    args = parser.parse_args()
    default_port, prefix, count, _ = SETS[args.set_name]
    args.port = default_port if args.port is None else args.port
    arms = ["baseline", *(f"{prefix}{n}" for n in range(1, count + 1))]
    selected = [x.strip() for x in args.arms.split(",")] if args.arms else arms
    args.tools = [x.strip() for x in args.tools.split(",")]
    if (args.minimum_relationships < 1 or args.seconds <= 0 or not 1024 <= args.port <= 65535 or
            not set(selected) <= set(arms) or len(set(selected)) != len(selected) or
            not set(args.tools) <= set(TOOLS) or len(set(args.tools)) != len(args.tools)):
        parser.error("Invalid budget, port, tools or arms")
    args.arms = [arm for arm in arms if arm in selected]
    args.repo = args.repo.resolve()
    args.output_base = args.output_base.resolve()
    return run(args)


if __name__ == "__main__":
    sys.exit(main())
