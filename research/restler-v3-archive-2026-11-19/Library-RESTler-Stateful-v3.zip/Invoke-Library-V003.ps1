[CmdletBinding()]
param(
    [string]$RepoPath = (Get-Location).Path,
    [string]$OutputBase,
    [string]$Python = 'python',
    [string]$ToolConfig,
    [string]$EvoMasterJar,
    [string]$RestlerPath,
    [string]$Java,
    [string]$Dotnet,
    [string]$RestlerPythonBin,
    [ValidateRange(1, 86400)][int]$Seconds = 60,
    [int]$Seed = 1,
    [ValidateSet('bfs-cheap','bfs-fast','random-walk')][string]$SearchStrategy = 'random-walk',
    [ValidateSet('full','stateful')][string]$CheckerProfile = 'stateful',
    [ValidateRange(1024, 65535)][int]$Port,
    [ValidateSet('restler', 'evomaster')][string[]]$Tools = @('restler', 'evomaster'),
    [switch]$SmokeOnly,
    [string[]]$Arms
)
$ErrorActionPreference = 'Stop'
$repo = (Resolve-Path -LiteralPath $RepoPath).Path
if (-not $OutputBase) {
    $OutputBase = Join-Path $env:USERPROFILE 'LibraryToolResults'
}
$campaignArgs = @(
    (Join-Path $PSScriptRoot 'campaign.py'),
    '--set', 'literature-v003',
    '--repo', $repo,
    '--output-base', $OutputBase,
    '--seconds', [string]$Seconds,
    '--seed', [string]$Seed,
    '--tools', ($Tools -join ','),
    '--search-strategy', $SearchStrategy,
    '--checker-profile', $CheckerProfile
)
if ($PSBoundParameters.ContainsKey('Port')) { $campaignArgs += @('--port', [string]$Port) }
if ($SmokeOnly) { $campaignArgs += '--smoke' }
if ($Arms) { $campaignArgs += @('--arms', ($Arms -join ',')) }
if ($ToolConfig) { $campaignArgs += @('--config', $ToolConfig) }
if ($EvoMasterJar) { $campaignArgs += @('--evomaster-jar', $EvoMasterJar) }
if ($RestlerPath) { $campaignArgs += @('--restler', $RestlerPath) }
if ($Java) { $campaignArgs += @('--java', $Java) }
if ($Dotnet) { $campaignArgs += @('--dotnet', $Dotnet) }
if ($RestlerPythonBin) { $campaignArgs += @('--restler-python-bin', $RestlerPythonBin) }

& $Python @campaignArgs
if ($LASTEXITCODE -ne 0) {
    throw "Campaign exited with code $LASTEXITCODE. Inspect RUN_DIRECTORY for logs and results."
}
