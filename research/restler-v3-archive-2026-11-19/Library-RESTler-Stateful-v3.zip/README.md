# Library RESTler trial v3: stateful search and explicit analysis status

This is a local trial, not a Git publication. Extract outside your repository.
The SUT code, schemas in the repository, fault mechanisms and old results are
not changed. The kit reuses the complete RESTler installation already built on
the work machine. It does not download/build it again when using Run-Work-RESTler-V3.ps1.

## First run on the work machine

Run `Run-Work-RESTler-V3.ps1 -Mode Validate -Seconds 60` from the extracted kit.
This starts only the literature-v003 BASELINE, with actual RESTler. It then
creates a ZIP in Downloads, including native logs and the complete HTTP trace.
Upload the file printed as UPLOAD_THIS. An explicit gate requires at least ten
successful loan creations AND ten successful hold creations. This is a small
operational coverage check, not a claim that all planted bugs are reachable.
Failed gates still produce the ZIP. No mutant is started in Validate mode.

After Windows validation, `Run-Work-RESTler-V3.ps1 -Mode Full -Seconds 60` runs
three native baseline smoke gates followed by all 18 cells in order:
- literature-v003: baseline, B1..B6, port 23600
- netbox-gitea: baseline, F1..F6, port 23601
- featurefuzz: baseline, C1..C3, port 23602

Every cell starts a fresh, verified-empty SUT. Servers are sequential in this
runner. Each full-campaign baseline must satisfy the stronger coverage gate and
native analyzer success. A failed baseline stops further mutants. Cell failures
and completed cells are saved. A final ZIP is printed even when the batch fails.

## What changed from v2

1. Search changes from bfs-cheap to random-walk. It is passed BOTH to the native
   driver as --search_strategy and to engine settings as fuzzing_mode, so the
   driver cannot silently retain its old breadth-first default. Native random
   walk keeps the engine's default max_sequence_length=100.
2. The stateful profile disables invalidvalue, payloadbody, invaliddynamicobject.
   Those checker passes consumed input-validation work before dependent operations
   were reached. The built-in main driver's 5xx detection and other default
   checkers remain active. RESTler's default disabled namespacerule stays disabled.
3. Native ResultsAnalyzer failure is detected even when the driver exits zero.
   summary.csv now includes native_analysis_status. If analysis failed/missing,
   execution becomes PARTIAL_ANALYSIS; the baseline gate stops the batch.
4. A normal baseline now needs >=10 successful POST /loans and >=10 successful
   POST /holds. Smoke mode only requires >=1 of each, since it tests API coverage.
5. Output defaults are outside AppData to avoid Windows Store Python filesystem
   redirection. The work launcher reuses the observed complete installation and
   copies the redirected engine into the physical installation only if missing.

This is a DISTINCT experimental configuration. Do not merge its detection rates
with v2's full-checker BFS runs. The three disabled checkers may detect defects
that this profile does not look for. The full profile is still available. A
successful analyzer in this profile does not fix the upstream parser for all
possible malformed requests: raw stderr/logs are retained, and any recurrence
is classified as a failed analysis rather than hidden.

The retained tool-only schema projection uses positive integer IDs, with explicit
public producer-consumer dependencies for user/book IDs. Numeric-string IDs are
not explored by that projection. The original schema is saved alongside it.
Loan deletion uses the user/book fields returned by loan creation. No fixed IDs,
manual seed scenario, internal state or planted-bug-specific guide is supplied.

## Parameters

Run-Work-RESTler-V3.ps1:
| Parameter | Default | Options / meaning |
| --- | --- | --- |
| Mode | Validate | Validate: one baseline and Downloads ZIP; Full: all smoke gates and 18 cells |
| Seconds | 60 | Integer 1..86400; native search budget per cell; startup/cleanup add overhead |
| OutputBase | C:\work\temp\LibraryToolResults | Results outside the repo and AppData |

The work launcher assumes the EXISTING isolated trial at
`%TEMP%\LibraryToolTrial-20261118-182918`, its venv and detached SUT checkout.
It uses the already-built installation under
`%LOCALAPPDATA%\LibraryToolTrials\restler-validated-20261119-145947-353bf1\tools\bin`
and the corresponding redirected tools.resolved.json identified in the diagnostics.
It does not modify the main checkout or the old v2 script kit.

The individual Invoke-Library-*.ps1 entry points support:
| Parameter | Default | Meaning |
| --- | --- | --- |
| RepoPath | Current directory | Integrated SUT checkout, read only |
| Python | python | Trial environment interpreter |
| OutputBase | USERPROFILE\LibraryToolResults | New per-campaign directory |
| ToolConfig | Repository config/manifest | Existing native tool paths |
| RestlerPath | Config/manifest | Complete Restler.dll or Restler.exe |
| RestlerPythonBin | Config/manifest | Python executable directory prepended to PATH |
| Dotnet, Java, EvoMasterJar | Config/manifest | Explicit native tool overrides |
| Seconds | 60 | Time budget per cell |
| Seed | 1 | Native random seed; SUT IDs remain random |
| Port | 23600/23601/23602 | Isolated listener for the selected set |
| Tools | restler,evomaster | One or both; work launcher selects only restler |
| Arms | baseline + all | Explicit subset of baseline/B1..B6, F1..F6, or C1..C3 |
| SmokeOnly | false | Native test mode instead of fuzz mode |
| SearchStrategy | random-walk | random-walk, bfs-fast, bfs-cheap |
| CheckerProfile | stateful | stateful or full |

For v2's native search/checker choices use -SearchStrategy bfs-cheap -CheckerProfile full.
The generic Run-Library-RESTler-Validated.ps1 supports RepoPath, Python, TrialRoot,
OutputBase, ToolConfig, Dotnet, RestlerBin, Seconds, Seed, SmokeOnly, SearchStrategy,
CheckerProfile. RestlerBin skips rebuilding; omit it only for a new complete build.
Its default OutputBase is USERPROFILE\LibraryToolResults. No branch changes or
Git pushes are performed. A .NET 8 SDK is required by its installation check.
The Python campaign CLI additionally permits --minimum-relationships (default10).

EvoMaster is retained as a manual entry-point option but has not been calibrated
or validated by this RESTler v3 work. Native reports are retained for later
review; successful HTTP creation and 'COMPLETED' are not planted-bug discoveries.
Equal nominal time is recorded; actual HTTP counts are measured, not equalized.

## Evidence and checks

See VALIDATION.json and validation-evidence/. Five regression checks cover schema
projection, dependency binding, missing installation components, successful-
creation accounting, and an analyzer failure masked by native exit zero.
Windows validation and the 18-arm full campaign are not claimed completed here.

Pinned RESTler source: 6d984deedbc54aad957fa3da0c7e9e5df23a2aee.
Primary reference implementation and documentation:
https://github.com/microsoft/restler-fuzzer/tree/6d984deedbc54aad957fa3da0c7e9e5df23a2aee
https://github.com/microsoft/restler-fuzzer/blob/6d984deedbc54aad957fa3da0c7e9e5df23a2aee/docs/user-guide/Fuzzing.md
