"""Regression checks for the schema mistakes seen in the first native trial."""
import json
from pathlib import Path
import tempfile
import unittest
from restler_support import project_spec, verify_grammar, installation_manifest, relation_counts


class RegressionTests(unittest.TestCase):
    def test_projection_preserves_original_and_links_composite_loan_key(self):
        original = {'info': {'version': '1', 'description': ''}, 'components': {'schemas': {
            **{name: {'properties': {key: {'oneOf': [{'type': 'integer'}, {'type': 'string'}]}
                for key in ('userId', 'bookId')}} for name in ('LoanCreate', 'HoldCreate')},
            'UserCreate': {'properties': {'name': {'type': 'string'}}},
            'BookCreate': {'properties': {'title': {'type': 'string'}}}}}, 'paths': {
            '/loans': {'post': {'responses': {}}}, '/holds': {'post': {'responses': {}}},
            '/loans/{user_id}/{book_id}': {'delete': {'parameters': [
                {'name': 'user_id'}, {'name': 'book_id'}], 'responses': {'204': {}}}}}}
        prior = json.dumps(original, sort_keys=True)
        projected = project_spec(original, 23600)
        self.assertEqual(prior, json.dumps(original, sort_keys=True))
        delete = projected['paths']['/loans/{user_id}/{book_id}']['delete']
        self.assertEqual([(a['producer_endpoint'], a['producer_resource_name'])
                         for a in delete['x-restler-annotations']], [('/loans', 'userId'), ('/loans', 'bookId')])
        self.assertEqual(set(delete['responses']), {'200'})
        for endpoint in ('/loans', '/holds'):
            self.assertEqual([a['producer_endpoint'] for a in projected['paths'][endpoint]['post']['x-restler-annotations']],
                             ['/users', '/books'])

    def test_grammar_rejects_unbound_and_object_ids(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'grammar.py'
            valid = ''.join(f'# Endpoint: {endpoint}, method: Post\n_users_post_id.reader()\n_books_post_id.reader()\n'
                            for endpoint in ('/loans', '/holds'))
            path.write_text(valid)
            self.assertTrue(all(verify_grammar(path).values()))
            path.write_text(valid.replace('_users_post_id.reader()', 'restler_fuzzable_int("1")', 1))
            with self.assertRaisesRegex(RuntimeError, 'Unresolved'):
                verify_grammar(path)
            path.write_text(valid + 'restler_fuzzable_object("{}")')
            with self.assertRaisesRegex(RuntimeError, 'object-valued'):
                verify_grammar(path)

    def test_missing_results_analyzer_is_an_installation_failure(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaisesRegex(RuntimeError, 'resultsAnalyzer/Restler.ResultsAnalyzer.dll'):
                installation_manifest(Path(folder) / 'restler' / 'Restler.dll')

    def test_400_attempts_do_not_satisfy_relationship_gate(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'http.jsonl'
            rows = [{'role': 'tool', 'method': 'POST', 'url': 'http://localhost/loans', 'status': 400},
                    {'role': 'tool', 'method': 'POST', 'url': 'http://localhost/holds', 'status': 201}]
            path.write_text('\n'.join(json.dumps(row) for row in rows))
            self.assertEqual(relation_counts(folder), {'loans_created': 0, 'holds_created': 1})



class NativeAnalysisRegression(unittest.TestCase):
    def test_engine_success_does_not_hide_analyzer_failure(self):
        from restler_support import native_analysis_status
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / 'Fuzz').mkdir()
            (root / 'Fuzz' / 'ResultsAnalyzerStdOut.txt').write_text('Analyzing logs')
            (root / 'native.log').write_text('ERROR: Results analyzer for logs failed.\nTask Fuzz succeeded.')
            self.assertEqual(native_analysis_status(root), 'FAILED')
            (root / 'native.log').write_text('Task Fuzz succeeded.')
            self.assertEqual(native_analysis_status(root), 'COMPLETED')

if __name__ == '__main__':
    unittest.main()
