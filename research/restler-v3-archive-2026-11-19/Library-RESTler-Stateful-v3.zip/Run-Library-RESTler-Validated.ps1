[CmdletBinding()]
param(
    [string]$TrialRoot = (Join-Path $env:TEMP 'LibraryToolTrial-20261118-182918'),
    [string]$RepoPath,
    [string]$Python,
    [string]$OutputBase,
    [string]$ToolConfig,
    [string]$Dotnet,
    [string]$RestlerBin,
    [ValidateRange(1, 86400)][int]$Seconds = 60,
    [int]$Seed = 1,
    [ValidateSet('bfs-cheap','bfs-fast','random-walk')][string]$SearchStrategy = 'random-walk',
    [ValidateSet('full','stateful')][string]$CheckerProfile = 'stateful',
    [switch]$SmokeOnly
)
$ErrorActionPreference = 'Stop'
if (-not $RepoPath) { $RepoPath = Join-Path $TrialRoot 'library-demo' }
if (-not $Python) { $Python = Join-Path $TrialRoot 'venv\Scripts\python.exe' }
if (-not $OutputBase) { $OutputBase = Join-Path $env:USERPROFILE 'LibraryToolResults' }
if (-not (Test-Path -LiteralPath $RepoPath -PathType Container)) { throw "Missing trial repo: $RepoPath" }
if (-not (Test-Path -LiteralPath $Python -PathType Leaf)) { throw "Missing trial Python: $Python" }
if (-not $ToolConfig) {
    $candidate = Join-Path (Get-Location).Path 'library\benchmark-v001\tools.local.json'
    if (Test-Path -LiteralPath $candidate -PathType Leaf) { $ToolConfig = $candidate }
}
$runArgs = @((Join-Path $PSScriptRoot 'validated_run.py'), '--repo', $RepoPath,
    '--output-base', $OutputBase, '--seconds', [string]$Seconds, '--seed', [string]$Seed,
    '--search-strategy', $SearchStrategy, '--checker-profile', $CheckerProfile)
if ($ToolConfig) { $runArgs += @('--config', $ToolConfig) }
if ($Dotnet) { $runArgs += @('--dotnet', $Dotnet) }
if ($RestlerBin) { $runArgs += @('--restler-bin', $RestlerBin) }
if ($SmokeOnly) { $runArgs += '--smoke-only' }
& $Python @runArgs
if ($LASTEXITCODE -ne 0) { throw 'Stopped at a validation gate. Upload the printed analysis ZIP.' }
