"""Tool-only schema projection and native installation integrity checks."""
import copy
import hashlib
import json
from pathlib import Path
import re


def project_spec(original, port):
    spec = copy.deepcopy(original)
    spec['servers'] = [{'url': f'http://127.0.0.1:{port}'}]
    spec['info']['version'] += '-numeric-id-projection-v2'
    spec['info']['description'] += (' Tool input projection: identifiers use the accepted positive-integer '
        'alternative, rather than the integer-or-string oneOf. This is a documented input-domain restriction. '
        'Explicit producer-consumer annotations describe public response fields; no planted fault is described.')
    for name in ('LoanCreate', 'HoldCreate'):
        for key in ('userId', 'bookId'):
            spec['components']['schemas'][name]['properties'][key] = {'type': 'integer', 'minimum': 1}
    for name, field in (('UserCreate', 'name'), ('BookCreate', 'title')):
        spec['components']['schemas'][name]['properties'][field]['example'] = 'LibraryTrial'
    for endpoint, operations in spec['paths'].items():
        for method, op in operations.items():
            if not isinstance(op, dict):
                continue
            annotations = []
            params = [p['name'] for p in op.get('parameters', [])]
            if method == 'post' and endpoint in ('/loans', '/holds'):
                params += ['userId', 'bookId']
            for param in params:
                if endpoint == '/loans/{user_id}/{book_id}':
                    producer, field = '/loans', {'user_id': 'userId', 'book_id': 'bookId'}[param]
                elif param in ('user_id', 'userId'):
                    producer, field = '/users', 'id'
                elif param in ('book_id', 'bookId'):
                    producer, field = '/books', 'id'
                elif param == 'hold_id':
                    producer, field = '/holds', 'id'
                else:
                    continue
                annotations.append(dict(producer_endpoint=producer, producer_method='POST',
                    producer_resource_name=field, consumer_param=param))
            if annotations:
                op['x-restler-annotations'] = annotations
            # Frozen service returns a JSON message and HTTP 200 for successful deletions.
            if method == 'delete' and '204' in op['responses']:
                op['responses']['200'] = {'description': 'Deleted', 'content': {'application/json': {
                    'schema': {'type': 'object', 'properties': {'message': {'type': 'string'}}}}}}
                del op['responses']['204']
    return spec


def verify_grammar(path):
    source = Path(path).read_text(encoding='utf-8')
    result = {}
    for endpoint in ('/loans', '/holds'):
        marker = f'# Endpoint: {endpoint}, method: Post'
        if marker not in source:
            raise RuntimeError(f'Missing generated request: {marker}')
        block = source.split(marker, 1)[1].split('# Endpoint:', 1)[0]
        for producer in ('users', 'books'):
            key = f'{endpoint}:POST<-{producer}:POST.id'
            result[key] = bool(re.search(r'_' + producer + r'_post_id\.reader\(\)', block))
        if 'restler_fuzzable_object' in block:
            raise RuntimeError(f'{endpoint} still has an object-valued ID; inspect grammar.py')
    if not all(result.values()):
        raise RuntimeError('Unresolved relationship dependencies: ' + json.dumps(result))
    return result


def installation_manifest(driver):
    root = Path(driver).resolve().parent.parent
    required = ('restler/Restler.dll', 'restler/Restler.runtimeconfig.json',
        'compiler/Restler.CompilerExe.dll', 'compiler/Restler.CompilerExe.runtimeconfig.json',
        'resultsAnalyzer/Restler.ResultsAnalyzer.dll',
        'resultsAnalyzer/Restler.ResultsAnalyzer.runtimeconfig.json', 'engine/restler.py')
    missing = [name for name in required if not (root / name).is_file()]
    if missing:
        raise RuntimeError('Incomplete RESTler installation: ' + ', '.join(missing))
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in required}


def relation_counts(folder):
    counts = {'loans_created': 0, 'holds_created': 0}
    path = Path(folder) / 'http.jsonl'
    if path.exists():
        from urllib.parse import urlsplit
        for line in path.read_text(encoding='utf-8').splitlines():
            row = json.loads(line)
            if row.get('role') == 'tool' and row.get('method') == 'POST' and row.get('status') == 201:
                endpoint = urlsplit(row['url']).path
                if endpoint in ('/loans', '/holds'):
                    counts[endpoint[1:] + '_created'] += 1
    return counts


def native_analysis_status(folder):
    folder = Path(folder)
    path = folder / 'native.log'
    log = path.read_text(errors='replace') if path.exists() else ''
    if 'ERROR: Results analyzer' in log:
        return 'FAILED'
    return 'COMPLETED' if list(folder.glob('*/ResultsAnalyzerStdOut.txt')) else 'NOT_RUN'
