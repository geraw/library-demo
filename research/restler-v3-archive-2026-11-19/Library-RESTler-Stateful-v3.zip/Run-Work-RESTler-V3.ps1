[CmdletBinding()]
param(
    [ValidateSet('Validate','Full')][string]$Mode = 'Validate',
    [ValidateRange(1,86400)][int]$Seconds = 60,
    [string]$OutputBase = 'C:\work\temp\LibraryToolResults'
)
$ErrorActionPreference = 'Stop'
$trial = Join-Path $env:TEMP 'LibraryToolTrial-20261118-182918'
$name = 'restler-validated-20261119-145947-353bf1'
$physical = Join-Path $env:LOCALAPPDATA "LibraryToolTrials\$name"
$redirected = Join-Path $env:LOCALAPPDATA (
    'Packages\PythonSoftwareFoundation.Python.3.12_qbz5n2kfra8p0' +
    "\LocalCache\Local\LibraryToolTrials\$name"
)
$binary = Join-Path $physical 'tools\bin'
$config = Join-Path $redirected 'tools.resolved.json'
$python = Join-Path $trial 'venv\Scripts\python.exe'
$repo = Join-Path $trial 'library-demo'
foreach ($path in @($python, $config, (Join-Path $binary 'restler\Restler.dll'))) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing prerequisite: $path" }
}
if (-not (Test-Path -LiteralPath (Join-Path $binary 'engine\restler.py'))) {
    $source = Join-Path $redirected 'tools\bin\engine'
    if (-not (Test-Path -LiteralPath (Join-Path $source 'restler.py'))) { throw "Engine missing: $source" }
    $destination = Join-Path $binary 'engine'
    New-Item -ItemType Directory -Path $destination -Force | Out-Null
    Get-ChildItem -LiteralPath $source -Force | Copy-Item -Destination $destination -Recurse -Force
}
if ($Mode -eq 'Full') {
    & (Join-Path $PSScriptRoot 'Run-Library-RESTler-Validated.ps1') `
        -RepoPath $repo -Python $python -RestlerBin $binary -ToolConfig $config `
        -OutputBase $OutputBase -Seconds $Seconds `
        -SearchStrategy random-walk -CheckerProfile stateful
} else {
    $output = Join-Path $OutputBase ('v3-validation-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
    New-Item -ItemType Directory -Path $output | Out-Null
    $zip = Join-Path $env:USERPROFILE ('Downloads\Library-RESTler-V3-Validation-' +
        (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.zip')
    try {
        & (Join-Path $PSScriptRoot 'Invoke-Library-V003.ps1') `
            -RepoPath $repo -Python $python -OutputBase $output -ToolConfig $config `
            -RestlerPath (Join-Path $binary 'restler\Restler.dll') `
            -RestlerPythonBin (Join-Path $trial 'venv\Scripts') `
            -Tools restler -Arms baseline -Seconds $Seconds `
            -SearchStrategy random-walk -CheckerProfile stateful
    } finally {
        Compress-Archive -LiteralPath $output -DestinationPath $zip
        "UPLOAD_THIS $zip"
    }
}
