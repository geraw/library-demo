"""Select the frozen server implementation for one isolated gateway process."""

import os
from pathlib import Path
from runpy import run_path


library = Path(os.environ["LIBRARY_CAMPAIGN_REPO"]) / "library"
set_name = os.environ["LIBRARY_CAMPAIGN_SET"]
arm = os.environ["LIBRARY_CAMPAIGN_ARM"]
if set_name == "literature-v003":
    app = run_path(str(library / "mutants-v003" / "mutants.py"))["create"](arm)
elif set_name == "netbox-gitea":
    app = run_path(str(library / "sut" / "library_sut_netbox_gitea.py"))["create_app"](
        None if arm == "baseline" else arm
    )
elif set_name == "featurefuzz":
    server = run_path(str(library / "feature-mutants-v001" / "server.py"))
    server["select_fault"](None if arm == "baseline" else arm)
    app = server["app"]
else:
    raise ValueError(set_name)
