"""Build a complete pinned RESTler, gate on native smoke coverage, then run three sets."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
sys.dont_write_bytecode = True
import time
import uuid
import zipfile

from restler_support import installation_manifest

REVISION = '6d984deedbc54aad957fa3da0c7e9e5df23a2aee'
HERE = Path(__file__).resolve().parent
SETS = ('literature-v003', 'netbox-gitea', 'featurefuzz')


def run(args):
    bench_dir = args.repo / 'library' / 'benchmark-v001'
    sys.path.insert(0, str(bench_dir))
    import campaign_v001 as bench
    root = args.output_base.resolve() / ('restler-validated-' + time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:6])
    root.mkdir(parents=True, exist_ok=False)
    print('BATCH_DIRECTORY', root, flush=True)
    config_path = args.config or bench_dir / 'tools.local.json'
    if args.config and not config_path.is_file():
        raise FileNotFoundError(config_path)
    config = bench.tool_config(config_path if config_path.is_file() else bench_dir / 'tools.example.json')
    dotnet = args.dotnet or config.get('dotnet') or shutil.which('dotnet')
    if dotnet and '/' not in dotnet and '\\' not in dotnet:
        dotnet = shutil.which(dotnet)
    if not dotnet:
        raise RuntimeError('A .NET 8 SDK is required. Pass -Dotnet with its dotnet.exe path.')
    if '/' in dotnet or '\\' in dotnet:
        dotnet = str(Path(dotnet).resolve())
    env = dict(os.environ, RESTLER_TELEMETRY_OPTOUT='1', DOTNET_CLI_TELEMETRY_OPTOUT='1', PYTHONDONTWRITEBYTECODE='1')
    env['PATH'] = str(Path(sys.executable).parent) + os.pathsep + str(Path(dotnet).parent) + os.pathsep + env.get('PATH', '')
    if Path(dotnet).is_file():
        env['DOTNET_ROOT'] = str(Path(dotnet).parent)
    results = []
    try:
        sdk = bench.launch([dotnet, '--list-sdks'], root, 'sdk', 60, env)
        bench.require(sdk, root, 'sdk')
        if not any(line.startswith('8.') for line in (root / 'sdk.log').read_text().splitlines()):
            raise RuntimeError('The selected dotnet has no .NET 8 SDK; inspect sdk.log')
        if args.restler_bin:
            binary = args.restler_bin.resolve()
        else:
            source = root / 'tools' / 'source'
            binary = root / 'tools' / 'bin'
            tools = root / 'tools'
            tools.mkdir()
            print('BUILD complete RESTler: compiler, driver, resultsAnalyzer, engine', flush=True)
            result = bench.launch(['git', 'clone', 'https://github.com/microsoft/restler-fuzzer.git', source], tools, 'clone', 600, env)
            bench.require(result, tools, 'clone')
            result = bench.launch(['git', '-C', source, 'checkout', '--detach', REVISION], tools, 'checkout', 60, env)
            bench.require(result, tools, 'checkout')
            result = bench.launch([sys.executable, source / 'build-restler.py', '--dest_dir', binary,
                                  '--compile_type', 'all'], tools, 'build', 1800, env)
            bench.require(result, tools, 'build')
            result = bench.launch([sys.executable, '-m', 'pip', 'install', '-r', source / 'restler' / 'requirements.txt'],
                                  tools, 'python-dependencies', 600, env)
            bench.require(result, tools, 'python-dependencies')
        driver = binary / 'restler' / 'Restler.dll'
        before = installation_manifest(driver)
        bench.write(root / 'installation-before.json', before)
        resolved = dict(config, restler=str(driver), restler_python_bin=str(Path(sys.executable).parent), dotnet=dotnet)
        bench.write(root / 'tools.resolved.json', resolved)
        print('RESTLER_COMPLETE', binary, flush=True)
        # All three baseline smoke tests must pass before any mutant or long run starts.
        for phase in ('smoke',) if args.smoke_only else ('smoke', 'campaign'):
            for name in SETS:
                stage = root / phase / name
                stage.mkdir(parents=True)
                print(phase.upper(), name, flush=True)
                command = [sys.executable, HERE / 'campaign.py', '--set', name, '--repo', args.repo,
                    '--output-base', stage, '--config', root / 'tools.resolved.json',
                    '--restler', driver, '--dotnet', dotnet, '--restler-python-bin', Path(sys.executable).parent,
                    '--tools', 'restler', '--seconds', args.seconds, '--seed', args.seed,
                    '--search-strategy', args.search_strategy, '--checker-profile', args.checker_profile]
                if phase == 'smoke':
                    command += ['--smoke', '--arms', 'baseline']
                budget = 900 if phase == 'smoke' else 600 + 7 * (args.seconds + 540)
                result = bench.launch(command, stage, 'campaign', budget, env)
                summaries = list(stage.glob('*/summary.json'))
                rows = json.loads(summaries[0].read_text()) if len(summaries) == 1 else []
                results.append({'phase': phase, 'set': name, 'execution': result, 'cells': rows})
                bench.write(root / 'batch-summary.json', results)
                for row in rows:
                    print(name, row['arm'], row['execution'],
                        'requests=' + str(row['http_requests']),
                        'loans=' + str(row.get('loans_created', 0)),
                        'holds=' + str(row.get('holds_created', 0)), flush=True)
                bench.require(result, stage, 'campaign')
                if installation_manifest(driver) != before:
                    raise RuntimeError('RESTler installation changed; remaining campaigns cancelled')
            if phase == 'smoke':
                print('ALL_THREE_NATIVE_SMOKE_GATES_PASSED', flush=True)
        bench.write(root / 'completed.json', {'smoke_only': args.smoke_only, 'sets': list(SETS)})
        return 0
    except BaseException as exc:
        bench.write(root / 'failure.json', {'error': str(exc), 'finished_campaigns': len(results)})
        print('STOPPED', str(exc), flush=True)
        return 1
    finally:
        # Keep tool binaries and source out of the review ZIP; include all request and native evidence.
        archive = root.with_name(root.name + '-analysis.zip')
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as zipped:
            for path in sorted(root.rglob('*')):
                if path.is_file() and path.relative_to(root).parts[0] != 'tools':
                    zipped.write(path, path.relative_to(root))
                elif path.is_file() and path.parent == root / 'tools':
                    zipped.write(path, path.relative_to(root))
        print('UPLOAD_THIS', archive, flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--output-base', type=Path, required=True)
    p.add_argument('--config', type=Path)
    p.add_argument('--dotnet')
    p.add_argument('--restler-bin', type=Path, help='Optional already-complete install; omit to build fresh')
    p.add_argument('--seconds', type=int, default=60)
    p.add_argument('--seed', type=int, default=1)
    p.add_argument('--smoke-only', action='store_true')
    p.add_argument('--search-strategy', choices=['bfs-cheap','bfs-fast','random-walk'], default='random-walk')
    p.add_argument('--checker-profile', choices=['full','stateful'], default='stateful')
    a = p.parse_args()
    if a.seconds <= 0:
        p.error('seconds must be positive')
    a.repo = a.repo.resolve()
    sys.exit(run(a))
